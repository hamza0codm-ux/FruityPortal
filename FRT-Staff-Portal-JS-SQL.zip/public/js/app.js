const app = document.getElementById('app');

const roleRank = { staff: 1, management: 2, owner: 3, admin: 4 };

function esc(value='') {
  return String(value).replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[c]));
}

async function api(url, options={}) {
  const response = await fetch(url, {
    ...options,
    headers: {'Content-Type':'application/json', ...(options.headers || {})}
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

function loginPage(error='') {
  app.innerHTML = `
    <main class="login">
      <section class="login-card">
        <div class="logo">FRT<span>.</span></div>
        <h1>Welcome back.</h1>
        <p>Enter the access code provided by an FRT Admin.</p>
        <form id="loginForm">
          <label>Access code
            <input id="passcode" placeholder="FRT-XXXX-XXXXXX" autocomplete="off" required>
          </label>
          <button class="primary">SIGN IN</button>
          <div class="error">${esc(error)}</div>
        </form>
      </section>
    </main>`;
  document.getElementById('loginForm').onsubmit = async e => {
    e.preventDefault();
    try {
      await api('/api/auth/login', {
        method:'POST',
        body:JSON.stringify({passcode:document.getElementById('passcode').value})
      });
      await dashboard();
    } catch (err) {
      loginPage(err.message);
    }
  };
}

async function dashboard() {
  let me;
  try { me = await api('/api/auth/me'); }
  catch { return loginPage(); }

  const isAdmin = me.role === 'admin';
  const isOwner = roleRank[me.role] >= roleRank.owner;

  app.innerHTML = `
    <div class="shell">
      <aside class="sidebar">
        <div class="brand">FRT<span>.</span></div>
        <div class="nav">
          <button class="active" data-page="home">Dashboard</button>
          <button data-page="news">News</button>
          <button data-page="rules">Rules</button>
          <button data-page="information">Information</button>
          <button data-page="guides">Guides</button>
          <button data-page="polls">Polls</button>
          <button data-page="tasks">Tasks</button>
          <button data-page="absence">Absence</button>
          <button data-page="roster">Roster</button>
          ${isAdmin ? '<button data-page="accounts">Staff Accounts</button>' : ''}
        </div>
      </aside>
      <main class="main">
        <header class="top">
          <div><h1 id="pageTitle">Dashboard</h1></div>
          <div class="user-pill">${esc(me.username)} · ${esc(me.role)}</div>
        </header>
        <section id="content"></section>
      </main>
    </div>`;

  document.querySelectorAll('.nav button').forEach(btn => {
    btn.onclick = () => {
      document.querySelectorAll('.nav button').forEach(x => x.classList.remove('active'));
      btn.classList.add('active');
      loadPage(btn.dataset.page, me);
    };
  });

  loadPage('home', me);
}

async function loadPage(page, me) {
  document.getElementById('pageTitle').textContent =
    page === 'home' ? 'Dashboard' :
    page === 'accounts' ? 'Staff Accounts' :
    page.charAt(0).toUpperCase() + page.slice(1);

  const content = document.getElementById('content');

  if (page === 'home') {
    content.innerHTML = `
      <div class="grid">
        <div class="card"><h3>Welcome</h3><p>Good to see you, ${esc(me.username)}.</p></div>
        <div class="card"><h3>Role</h3><div class="stat">${esc(me.role).toUpperCase()}</div></div>
        <div class="card"><h3>Team</h3><div class="stat">${esc(me.team || '—')}</div></div>
      </div>
      <div class="section card">
        <div class="section-head"><h3>Quick access</h3><button class="small-btn" id="logout">Log out</button></div>
        <p>Your FRT workspace is ready. Staff see staff content, while Management, Owners and Admins receive progressively higher access.</p>
      </div>`;
    document.getElementById('logout').onclick = async () => {
      await api('/api/auth/logout', {method:'POST'});
      loginPage();
    };
    return;
  }

  if (page === 'accounts') return accountsPage(content);
  content.innerHTML = `
    <div class="card">
      <h3>${esc(page.charAt(0).toUpperCase()+page.slice(1))}</h3>
      <p>This section is wired into the portal structure. The PostgreSQL tables and role permissions are already prepared for it.</p>
    </div>`;
}

async function accountsPage(content) {
  try {
    const accounts = await api('/api/accounts');
    content.innerHTML = `
      <div class="section-head">
        <div><h2>Staff accounts</h2><p style="color:var(--muted)">Only Admins can create, edit, deactivate, or issue access codes.</p></div>
        <button class="small-btn" id="add">+ Add staff</button>
      </div>
      <div class="card">
        <table class="table">
          <thead><tr><th>Username</th><th>Role</th><th>Team</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>
            ${accounts.map(a => `
              <tr>
                <td>${esc(a.username)}</td>
                <td><span class="badge">${esc(a.role)}</span></td>
                <td>${esc(a.team || '—')}</td>
                <td>${esc(a.status)}</td>
                <td><div class="actions">
                  <button class="small-btn" data-code="${a.id}">New code</button>
                  <button class="small-btn" data-toggle="${a.id}" data-status="${a.status}">${a.status==='active'?'Deactivate':'Activate'}</button>
                </div></td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`;

    document.getElementById('add').onclick = () => addStaffModal();
    content.querySelectorAll('[data-code]').forEach(b => b.onclick = () => newCode(b.dataset.code));
    content.querySelectorAll('[data-toggle]').forEach(b => b.onclick = () => toggleAccount(b.dataset.toggle, b.dataset.status));
  } catch (e) {
    content.innerHTML = `<div class="card"><div class="error">${esc(e.message)}</div></div>`;
  }
}

function modal(html) {
  const wrap = document.createElement('div');
  wrap.className = 'modal';
  wrap.innerHTML = `<div class="modal-card">${html}</div>`;
  document.body.appendChild(wrap);
  return wrap;
}

function addStaffModal() {
  const m = modal(`
    <h2>Add staff account</h2>
    <p style="color:var(--muted)">No email or password is required. Admins issue the FRT access code.</p>
    <form id="addForm" class="form-grid">
      <label>Username<input id="username" required></label>
      <label>Role<select id="role"><option>staff</option><option>management</option><option>owner</option><option>admin</option></select></label>
      <label>Team<input id="team" placeholder="Discord, Marketing, Community..."></label>
      <label>Code expiry<select id="days"><option value="7">7 days</option><option value="30" selected>30 days</option><option value="90">90 days</option><option value="365">365 days</option></select></label>
      <div class="actions"><button type="button" class="small-btn" id="cancel">Cancel</button><button class="primary" style="width:auto;margin:0">CREATE ACCOUNT</button></div>
      <div class="error" id="err"></div>
    </form>`);
  m.querySelector('#cancel').onclick = () => m.remove();
  m.querySelector('#addForm').onsubmit = async e => {
    e.preventDefault();
    try {
      const data = await api('/api/accounts', {
        method:'POST',
        body:JSON.stringify({
          username:m.querySelector('#username').value,
          role:m.querySelector('#role').value,
          team:m.querySelector('#team').value,
          expiresDays:m.querySelector('#days').value
        })
      });
      m.querySelector('.modal-card').innerHTML = `
        <h2>Account created</h2>
        <p style="color:var(--muted)">Give this code privately to the staff member.</p>
        <div class="passcode">${esc(data.passcode)}</div>
        <button class="primary" id="done">DONE</button>`;
      m.querySelector('#done').onclick = () => { m.remove(); accountsPage(document.getElementById('content')); };
    } catch (err) {
      m.querySelector('#err').textContent = err.message;
    }
  };
}

async function newCode(id) {
  if (!confirm('Generate a new access code? The old code will stop working.')) return;
  try {
    const data = await api(`/api/accounts/${id}/passcode`, {
      method:'POST',
      body:JSON.stringify({expiresDays:30})
    });
    const m = modal(`<h2>New access code</h2><p style="color:var(--muted)">Give this code privately to the staff member.</p><div class="passcode">${esc(data.passcode)}</div><button class="primary" id="close">DONE</button>`);
    m.querySelector('#close').onclick = () => { m.remove(); accountsPage(document.getElementById('content')); };
  } catch (e) { alert(e.message); }
}

async function toggleAccount(id, status) {
  const next = status === 'active' ? 'inactive' : 'active';
  if (!confirm(`${next === 'inactive' ? 'Deactivate' : 'Activate'} this account?`)) return;
  try {
    await api(`/api/accounts/${id}`, {method:'PATCH', body:JSON.stringify({status:next})});
    accountsPage(document.getElementById('content'));
  } catch (e) { alert(e.message); }
}

dashboard();
