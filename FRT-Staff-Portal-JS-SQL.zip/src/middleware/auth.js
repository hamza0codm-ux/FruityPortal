import crypto from 'node:crypto';
import { query } from '../database/postgresDatabase.js';

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export async function attachUser(req, res, next) {
  try {
    const token = req.cookies?.frt_session;
    if (!token) return next();

    const result = await query(`
      SELECT s.id AS session_id, a.*
      FROM sessions s
      JOIN staff_accounts a ON a.id = s.staff_id
      WHERE s.token_hash = $1
        AND s.expires_at > NOW()
        AND a.status = 'active'
    `, [hashToken(token)]);

    req.user = result.rows[0] || null;
    next();
  } catch (error) {
    next(error);
  }
}

export function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  next();
}

export function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}

export function roleAtLeast(role, minimum) {
  const levels = { staff: 1, management: 2, owner: 3, admin: 4 };
  return levels[role] >= levels[minimum];
}

export function requireMinimumRole(minimum) {
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
    if (!roleAtLeast(req.user.role, minimum)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}
