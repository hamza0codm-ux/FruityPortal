import { Router } from 'express';
import { query } from '../database/postgresDatabase.js';
import { generatePasscode, hashPasscode } from '../utils/security.js';
import { requireRole } from '../middleware/auth.js';
import { audit } from '../utils/audit.js';

const router = Router();

router.get('/', requireRole('admin'), async (req, res, next) => {
  try {
    const result = await query(`
      SELECT id, username, role, team, status, passcode_expires_at, created_at, updated_at
      FROM staff_accounts
      ORDER BY id DESC
    `);
    res.json(result.rows);
  } catch (error) {
    next(error);
  }
});

router.post('/', requireRole('admin'), async (req, res, next) => {
  try {
    const username = String(req.body?.username || '').trim();
    const role = String(req.body?.role || 'staff').toLowerCase();
    const team = String(req.body?.team || '').trim() || null;
    const expiresDays = Math.max(1, Math.min(365, Number(req.body?.expiresDays || 30)));

    if (!username) return res.status(400).json({ error: 'Username is required.' });
    if (!['staff','management','owner','admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role.' });
    }

    const passcode = generatePasscode();
    const result = await query(`
      INSERT INTO staff_accounts
        (username, role, team, passcode_hash, passcode_expires_at, created_by)
      VALUES ($1,$2,$3,$4,NOW() + ($5 * INTERVAL '1 day'),$6)
      RETURNING id, username, role, team, status, passcode_expires_at, created_at
    `, [username, role, team, hashPasscode(passcode), expiresDays, req.user.id]);

    const account = result.rows[0];
    await audit(req.user.id, 'staff_account_created', 'staff_account', account.id, {
      username, role, team
    });

    res.status(201).json({ account, passcode });
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Username already exists.' });
    next(error);
  }
});

router.post('/:id/passcode', requireRole('admin'), async (req, res, next) => {
  try {
    const passcode = generatePasscode();
    const days = Math.max(1, Math.min(365, Number(req.body?.expiresDays || 30)));

    const result = await query(`
      UPDATE staff_accounts
      SET passcode_hash = $1,
          passcode_expires_at = NOW() + ($2 * INTERVAL '1 day'),
          updated_at = NOW()
      WHERE id = $3
      RETURNING id, username, role, team, status, passcode_expires_at
    `, [hashPasscode(passcode), days, req.params.id]);

    if (!result.rows[0]) return res.status(404).json({ error: 'Staff account not found.' });

    await audit(req.user.id, 'staff_passcode_rotated', 'staff_account', req.params.id);
    res.json({ account: result.rows[0], passcode });
  } catch (error) {
    next(error);
  }
});

router.patch('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    const username = req.body?.username;
    const role = req.body?.role;
    const team = req.body?.team;
    const status = req.body?.status;

    if (role && !['staff','management','owner','admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role.' });
    }
    if (status && !['active','inactive'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status.' });
    }

    const result = await query(`
      UPDATE staff_accounts
      SET username = COALESCE($1, username),
          role = COALESCE($2, role),
          team = COALESCE($3, team),
          status = COALESCE($4, status),
          updated_at = NOW()
      WHERE id = $5
      RETURNING id, username, role, team, status, passcode_expires_at, updated_at
    `, [username ?? null, role ?? null, team ?? null, status ?? null, req.params.id]);

    if (!result.rows[0]) return res.status(404).json({ error: 'Staff account not found.' });

    await audit(req.user.id, 'staff_account_updated', 'staff_account', req.params.id, {
      username, role, team, status
    });
    res.json(result.rows[0]);
  } catch (error) {
    if (error.code === '23505') return res.status(409).json({ error: 'Username already exists.' });
    next(error);
  }
});

router.delete('/:id', requireRole('admin'), async (req, res, next) => {
  try {
    if (String(req.params.id) === String(req.user.id)) {
      return res.status(400).json({ error: 'You cannot remove your own account.' });
    }

    const result = await query(`
      UPDATE staff_accounts
      SET status = 'inactive', passcode_hash = NULL, passcode_expires_at = NULL, updated_at = NOW()
      WHERE id = $1
      RETURNING id, username
    `, [req.params.id]);

    if (!result.rows[0]) return res.status(404).json({ error: 'Staff account not found.' });

    await audit(req.user.id, 'staff_account_deactivated', 'staff_account', req.params.id);
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

export default router;
