import { Router } from 'express';
import { query, transaction } from '../database/postgresDatabase.js';
import { generateSessionToken, hashPasscode, hashSessionToken } from '../utils/security.js';

const router = Router();

router.post('/login', async (req, res, next) => {
  try {
    const passcode = String(req.body?.passcode || '').trim().toUpperCase();

    if (!/^FRT-[A-Z0-9]{4}-[A-Z0-9]{6}$/.test(passcode)) {
      return res.status(400).json({ error: 'Enter a valid FRT access code.' });
    }

    const user = await transaction(async client => {
      const result = await client.query(`
        SELECT *
        FROM staff_accounts
        WHERE passcode_hash = $1
          AND status = 'active'
          AND (passcode_expires_at IS NULL OR passcode_expires_at > NOW())
        LIMIT 1
        FOR UPDATE
      `, [hashPasscode(passcode)]);

      if (!result.rows[0]) return null;

      const account = result.rows[0];
      const token = generateSessionToken();

      await client.query(`
        INSERT INTO sessions (token_hash, staff_id, expires_at)
        VALUES ($1,$2,NOW() + INTERVAL '7 days')
      `, [hashSessionToken(token), account.id]);

      // The access code is deliberately not deleted here.
      // Admins can rotate/revoke it by generating a new code.
      return { account, token };
    });

    if (!user) return res.status(401).json({ error: 'Invalid or expired access code.' });

    res.cookie('frt_session', user.token, {
      httpOnly: true,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000,
      path: '/'
    });

    res.json({
      ok: true,
      user: {
        id: user.account.id,
        username: user.account.username,
        role: user.account.role,
        team: user.account.team
      }
    });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', async (req, res, next) => {
  try {
    const token = req.cookies?.frt_session;
    if (token) {
      await query('DELETE FROM sessions WHERE token_hash = $1', [hashSessionToken(token)]);
    }
    res.clearCookie('frt_session', { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', path: '/' });
    res.json({ ok: true });
  } catch (error) {
    next(error);
  }
});

router.get('/me', (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not authenticated' });
  res.json({
    id: req.user.id,
    username: req.user.username,
    role: req.user.role,
    team: req.user.team
  });
});

export default router;
