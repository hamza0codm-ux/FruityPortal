import { query } from '../database/postgresDatabase.js';

export async function audit(actorId, action, targetType = null, targetId = null, details = {}) {
  await query(`
    INSERT INTO audit_logs (actor_id, action, target_type, target_id, details)
    VALUES ($1,$2,$3,$4,$5)
  `, [actorId, action, targetType, targetId, JSON.stringify(details)]);
}
