import crypto from 'node:crypto';

export function generatePasscode() {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let raw = '';
  for (let i = 0; i < 10; i++) {
    raw += alphabet[crypto.randomInt(0, alphabet.length)];
  }
  return `FRT-${raw.slice(0, 4)}-${raw.slice(4)}`;
}

export function hashPasscode(passcode) {
  return crypto.createHash('sha256').update(passcode.trim().toUpperCase()).digest('hex');
}

export function generateSessionToken() {
  return crypto.randomBytes(48).toString('hex');
}

export function hashSessionToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}
